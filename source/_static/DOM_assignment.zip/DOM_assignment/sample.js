$(document).ready(function(){

    //画像にマウスをかざしたら画像が切り替わる
    $('img').hover(function(){
        $(this).attr('src', $(this).attr('src').replace('_front', '_back'));
    }, function(){
        if (!$(this).hasClass('currentPage')) {
            $(this).attr('src', $(this).attr('src').replace('_back', '_front'));
        }
    });

	//画像をクリックしたら選択状態になり、合計金額の情報が更新される
	var total = 0;
	$('img').click(function(){
	    $(this).toggleClass("selected");
		var price = $(this).attr("value");
		total = $(this).hasClass("selected") ? total + parseInt(price) : total - parseInt(price);
		$("#total").text("合計金額: ￥" + total);
	});
	
	//「詳細」をクリックしたら製品情報がスライドされる
	$(".detail").click(function(){
	    $(".info",this).slideToggle();
	});
	
});