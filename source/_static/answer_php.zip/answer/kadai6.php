<?php

error_reporting(E_ALL);

class Smartphone
{
    /**
     * 電話番号
     * @var string
     */
    private $number;
    
    /**
     * 通信事業者
     * @var string
     */
    private $carrier;
    
    /**
     * 機種名
     * @var string
     */
    private $model;
    
    /**
     * OS名
     * @var string
     */
    private $os;
    
    /**
     * 
     * @param string $number
     * @param string $carrier
     * @param string $model
     * @param string $os
     */
    public function __construct($number, $carrier, $model, $os)
    {
        $this->number = $number;
        $this->carrier = $carrier;
        $this->model = $model;
        $this->os = $os;
    }
    
    /**
     * 
     * @return string
     */
    public function getNumber()
    {
        return $this->number;
    }
    
    /**
     * 
     * @return string
     */
    public function getCarrier()
    {
        return $this->carrier;
    }
    
    /**
     * 
     * @return string
     */
    public function getModel()
    {
        return $this->model;
    }
    
    /**
     * 
     * @return string
     */
    public function getOs()
    {
        return $this->os;
    }
}


class Featurephone
{
    /**
     * 電話番号
     * @var string
     */
    private $number;
    
    /**
     * 通信事業者
     * @var string
     */
    private $carrier;
    
    /**
     * 機種名
     * @var string
     */
    private $model;
    
    /**
     * 実行できるアプリ名
     * @var string
     */
    private $application;
    
    /**
     * 
     * @param string $number
     * @param string $carrier
     * @param string $model
     * @param string $os
     */
    public function __construct($number, $carrier, $model, $application)
    {
        $this->number = $number;
        $this->carrier = $carrier;
        $this->model = $model;
        $this->application = $application;
    }
    
    /**
     * 
     * @return string
     */
    public function getNumber()
    {
        return $this->number;
    }
    
    /**
     * 
     * @return string
     */
    public function getCarrier()
    {
        return $this->carrier;
    }
    
    /**
     * 
     * @return string
     */
    public function getModel()
    {
        return $this->model;
    }
    
    /**
     * 
     * @return string
     */
    public function getApplication()
    {
        return $this->application;
    }
}

$smartphone = new Smartphone('080-2222-2222', 'docomo', 'iPhone5', 'iOS6');
$featurephone = new Featurephone('090-7777-7777', 'au', 'W61SH', 'EZアプリ');
var_dump($smartphone);
var_dump($featurephone);