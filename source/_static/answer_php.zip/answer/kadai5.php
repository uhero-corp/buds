<?php

error_reporting(E_ALL);

class PrimePrinter
{

    /**
     * 
     */
    public function printPrime()
    {
        $unprime = array();
        for ($s = 1; $s < 100; $s++) {
            if (!$this->checkPrime($s)) {
                $unprime[$s] = $this->divisibleList($s);
            }
        }
        $this->printKanjiPrime($unprime);
    }
    
    /**
     * 
     * @param array $unprime
     */
    private function printKanjiPrime($unprime)
    {
        $kanjiUnprime = array();
        foreach ($unprime as $key => $value) {
            foreach ($value as $key2 => $value2) {
                $kanjiUnprime[$key][$key2] = $this->kanjiNumeral($value2);
            }
        }
        print_r($kanjiUnprime);        
    }

    /**
     * 
     * @param int $number
     * @return array
     */
    private function divisibleList($number)
    {
        $divisibleList = array();
        for ($i = 1; $i <= $number; $i++) {
            if ($number % $i === 0) {
                $divisibleList[] = $i;
            }
        }
        return $divisibleList;
    }

    /**
     * 
     * @param int $number
     * @return string
     */
    private function kanjiNumeral($number)
    {
        $kanji = array('〇', '一', '二', '三', '四', '五', '六', '七', '八', '九');
        $new = '';
        foreach (str_split($number) as $value) {
            $new = $new . $kanji[$value];
        }
        return $new;
    }

    /**
     * 
     * @param int $number
     * @return boolean
     */
    private function checkPrime($number)
    {
        if ($number < 2) {
            return false;
        } else if ($number === 2) {
            return true;
        }
        for ($i = 2; $i < $number; $i++) {
            if ($number % $i === 0) {
                return false;
            }
        }
        return true;
    }

}

$primePrinter = new PrimePrinter();
$primePrinter->printPrime();