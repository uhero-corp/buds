<?php

error_reporting(E_ALL);

abstract class Mobilephone
{
    /**
     * 電話番号
     * @var string
     */
    private $number;
    
    /**
     * 通信事業者
     * @var string
     */
    private $carrier;
    
    /**
     * 機種名
     * @var string
     */
    private $model;
    
    /**
     * 
     * @param string $number
     * @param string $carrier
     * @param string $model
     */
    public function __construct($number, $carrier, $model)
    {
        $this->number = $number;
        $this->carrier = $carrier;
        $this->model = $model;
    }

    /**
     * 
     * @return string
     */
    public function getNumber()
    {
        return $this->number;
    }
    
    /**
     * 
     * @return string
     */
    public function getCarrier()
    {
        return $this->carrier;
    }
    
    /**
     * 
     * @return string
     */
    public function getModel()
    {
        return $this->model;
    }    
}

class Smartphone extends Mobilephone
{
    /**
     * OS名 
     * @var string
     */
    private $os;
    
    /**
     * 
     * @param string $number
     * @param string $carrier
     * @param string $model
     * @param string $os
     */
    public function __construct($number, $carrier, $model, $os = '')
    {
        parent::__construct($number, $carrier, $model);
        $this->os = $os;
    }
    
    /**
     * 
     * @return string
     */
    public function getOs()
    {
        return $this->os;
    }
}

class Featurephone extends Mobilephone
{
    /**
     * 実行可能なアプリ名 
     * @var string
     */
    private $application;
    
    /**
     * 
     * @param string $number
     * @param string $carrier
     * @param string $model
     * @param string $application
     */
    public function __construct($number, $carrier, $model, $application = '')
    {
        parent::__construct($number, $carrier, $model);
        $this->application = $application;
    }
    
    /**
     * 
     * @return string
     */
    public function getApplication()
    {
        return $this->application;
    }
}

$smartphone = new Smartphone('080-2222-2222', 'docomo', 'iPhone5', 'iOS6');
$featurephone = new Featurephone('090-7777-7777', 'au', 'W61SH', 'EZアプリ');
var_dump($smartphone);
var_dump($featurephone);
