<?php

class TweetAnalyzer
{
    /**
     * 
     * @param string $filename
     * @return array
     */
    public function analyzeTweet($filename)
    {
        $timeListMaker = new TimeListMaker();
        $hourListMaker = new HourListMaker();
        $hourListCounter = new HourListCounter();
        $countListPrinter = new CountListPrinter();
        $json = file_get_contents($filename);
        $tweet = json_decode($json, true);
        $timeList = $timeListMaker->makeTimeList($tweet);
        $hourList = $hourListMaker->makeHourList($timeList);
        $countList = $hourListCounter->count($hourList);
        $countListPrinter->printCountList($countList);
    }   
}