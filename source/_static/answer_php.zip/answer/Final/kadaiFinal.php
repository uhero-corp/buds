<?php

error_reporting(E_ALL);
date_default_timezone_set('Asia/Tokyo');

require_once 'CountListPrinter.php';
require_once 'HourListCounter.php';
require_once 'HourListMaker.php';
require_once 'TimeListMaker.php';
require_once 'TweetAnalyzer.php';


$tweetAnalyzer = new TweetAnalyzer();
$tweetAnalyzer->analyzeTweet('tweet.json');