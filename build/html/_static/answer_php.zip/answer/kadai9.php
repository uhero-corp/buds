<?php

error_reporting(E_ALL);

interface AppleProduct
{
    /**
     * 
     * @return string シリアル番号
     */
    public function getSerial();
}

class Mac implements AppleProduct
{
    /**
     * シリアル番号 
     * @var string
     */
    private $serial;
    
    /**
     * 機種名
     * @var string
     */
    private $model;
    
    /**
     * OS名
     * @var string
     */
    private $os;
    
    /**
     * CPUメーカー
     * @var string
     */
    private $cpuMaker;
    
    /**
     * 
     * @param string $serial
     * @param string $model
     * @param string $os
     * @param string $cpuMaker
     */
    public function __construct($serial, $model, $os, $cpuMaker)
    {
        $this->serial = $serial;
        $this->model = $model;
        $this->os = $os;
        $this->cpuMaker = $cpuMaker;
    }
    
    /**
     * 
     * @return string
     */
    public function getSerial()
    {
        return $this->serial;
    }
    
    /**
     * 
     * @return string
     */
    public function getModel()
    {
        return $this->model;
    }
    
    /**
     * 
     * @return string
     */
    public function getOs()
    {
        return $this->os;
    }
    
    /**
     * 
     * @return string
     */
    public function getCpuMaker()
    {
        return $this->cpuMaker;
    }
}

class IpodTouch implements AppleProduct
{
    /**
     * シリアル番号 
     * @var string
     */
    private $serial;
    
    /**
     * 機種名
     * @var string
     */
    private $model;
    
    /**
     * OS名
     * @var string
     */
    private $os;
    
    /**
     * 容量
     * @var string
     */
    private $capacity;
    
    /**
     * 
     * @param string $serial
     * @param string $model
     * @param string $os
     * @param string $capacity
     */
    public function __construct($serial, $model, $os, $capacity)
    {
        $this->serial = $serial;
        $this->model = $model;
        $this->os = $os;
        $this->capacity = $capacity;
    }
    
    /**
     * 
     * @return string
     */
    public function getSerial()
    {
        return $this->serial;
    }
    
    /**
     * 
     * @return string
     */
    public function getModel()
    {
        return $this->model;
    }
    
    /**
     * 
     * @return string
     */
    public function getOs()
    {
        return $this->os;
    }
    
    /**
     * 
     * @return string
     */
    public function getCapacity()
    {
        return $this->capacity;
    }
}

abstract class Mobilephone
{
    /**
     * 電話番号
     * @var string
     */
    private $number;
    
    /**
     * 通信事業者
     * @var string
     */
    private $carrier;
    
    /**
     * 機種名 
     * @var string
     */
    private $model;
    
    /**
     * 
     * @param string $number
     * @param string $carrier
     * @param string $model
     */
    public function __construct($number, $carrier, $model)
    {
        $this->number = $number;
        $this->carrier = $carrier;
        $this->model = $model;
    }

    /**
     * 
     * @return string
     */
    public function getNumber()
    {
        return $this->number;
    }
    
    /**
     * 
     * @return string
     */
    public function getCarrier()
    {
        return $this->carrier;
    }
    
    /**
     * 
     * @return string
     */
    public function getModel()
    {
        return $this->model;
    }    
}

class Smartphone extends Mobilephone
{
    /**
     * OS名 
     * @var string
     */
    private $os;
    
    /**
     * 
     * @param string $number
     * @param string $carrier
     * @param string $model
     * @param string $os
     */
    public function __construct($number, $carrier, $model, $os = '')
    {
        parent::__construct($number, $carrier, $model);
        $this->os = $os;
    }
    
    /**
     * 
     * @return string
     */
    public function getOs()
    {
        return $this->os;
    }
}

class Featurephone extends Mobilephone
{
    /**
     * アプリケーション名
     * @var string
     */
    private $application;
    
    /**
     * 
     * @param string $number
     * @param string $carrier
     * @param string $model
     * @param string $application
     */
    public function __construct($number, $carrier, $model, $application = '')
    {
        parent::__construct($number, $carrier, $model);
        $this->application = $application;
    }
    
    /**
     * 
     * @return string
     */
    public function getApplication()
    {
        return $this->application;
    }
}

class Iphone extends Smartphone implements AppleProduct
{
    /**
     * シリアル番号 
     * @var string
     */
    private $serial;
    
    public function __construct($number, $carrier, $model, $os = '', $serial = '')
    {
        parent::__construct($number, $carrier, $model, $os);
        $this->serial = $serial;
    }
    
    public function getSerial()
    {
        return $this->serial;
    }
}

class AppleStore
{
    /**
     * 在庫情報
     * @var array
     */
    private $products = array();
    
    /**
     * 
     * @param array $products
     * @throws Exception
     */
    public function __construct($products)
    {
        foreach ($products as $product) {
            if ($product instanceof AppleProduct) {
                $this->products[] = $product;
            } else {
                throw new Exception;
            }
        }
    }
    
    /**
     * 
     * @param AppleProduct $product
     */
    public function add(AppleProduct $product)
    {
        $this->products[] = $product;
    }
    
    /**
     * 
     * @return array
     */
    public function getSerialList()
    {
        $serialList = array();
        foreach ($this->products as $value) {
            $serialList[] = $value->getSerial();
        }
        return $serialList;
    }
}

$iphone = new Iphone('080-2222-2222', 'docomo', 'iPhone5', 'iOS6', 'X001QWERTYUIOP');
$mac = new Mac('X09878LKJHGFDS', 'MacBook Pro Retina 13.3', 'MacOS X 10.9', 'Intel');
$ipodTouch = new IpodTouch('C456787TYFTY', 'iPodTouch 4g', 'iOS6', '64GB');

$applestore = new AppleStore([$iphone, $mac, $ipodTouch]);
print_r($applestore->getSerialList());