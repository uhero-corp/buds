<?php

class CountListPrinter
{
    /**
     *
     * @param array $countList
     * @return array
     */
    public function printCountList($countList)
    {
        foreach ($countList as $hour => $value) {
            echo "{$hour}時 {$value}回" . PHP_EOL;
        }
    }
}