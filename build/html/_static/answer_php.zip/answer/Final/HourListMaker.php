<?php

class HourListMaker
{
    /**
     * 
     * @param array $timeList
     * @return array 中身はint型です。
     */
    public function makeHourList($timeList)
    {
        $hourList = array();
        foreach ($timeList as $value) {
            $unixTime = strtotime($value);
            $hour = date("H", $unixTime);
            $hourList[] = intval($hour);
        }
        return $hourList;
    }
}