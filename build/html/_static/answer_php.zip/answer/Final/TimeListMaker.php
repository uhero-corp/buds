<?php

class TimeListMaker
{
    /**
     * 
     * @param array $tweet
     * @return array
     */
    public function makeTimeList($tweet)
    {
        $timeList = array();
        foreach ($tweet as $value) {
            $timeList[] = $value[created_at];
        }
        return $timeList;
    }
    
}
