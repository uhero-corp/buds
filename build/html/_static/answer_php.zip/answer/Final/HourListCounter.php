<?php

class HourListCounter
{
    /**
     * 
     * @param array $hourList
     * @return array
     */
    public function count($hourList)
    {
        $countList = array();
        for($i = 0; $i < 24; $i++){
            $count = array_keys($hourList, $i);
            $countList[$i] = count($count);
        }
        return $countList;
    }
}