<?php

/**
 * (1) 除算を行う関数
 * @param int $divident 割られる数
 * @param int $divisor 割る数
 */
function divideNumber($divident, $divisor)
{
	if ($divisor == 0 || !is_numeric($divident) || !is_numeric($divisor)) {
		throw new InvalidArgumentException("不正な値です");
	}
	
	return $divident / $divisor;
}


//(2)
$values = array(1, 5, 6, 2, 0, 4, "hogehoge", 7, 3,);
foreach ($values as $value) {
	try {
		divideNumber(15120, $value);
		echo "実行しました\n";
	} catch (InvalidArgumentException $e) {
		echo $e->getMessage() . "\n";
	}
}

//(3)
$values = array(1, 5, 6, 2, 0, 4, "hogehoge", 7, 3,);
foreach ($values as $value) {
	try {
		divideNumber(15120, $value);
		echo "実行しました\n";
	} catch (InvalidArgumentException $e) {
		echo $e->getMessage() . "\n";
		exit;
	}
}