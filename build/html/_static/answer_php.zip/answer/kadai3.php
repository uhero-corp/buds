<?php

/**
 * 
 * @param int $number
 * @return string
 */
function kanjiNumeral($number)
{
    $kanji = array('〇', '一', '二', '三', '四', '五', '六', '七', '八', '九');
    $new = '';
    foreach (str_split($number) as $value) {
        $new = $new . $kanji[$value];
    }
    return $new;
}

for ($i = 0; $i < 100; $i++) {
    echo kanjiNumeral($i) . PHP_EOL;
}