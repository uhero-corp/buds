<?php

/**
 * 
 * @param int $number
 * @return boolean
 */
function checkPrime($number)
{
    if ($number < 2) {
        return false;
    } else if ($number === 2) {
        return true;
    }
    for ($i = 2; $i < $number; $i++) {
        if ($number % $i === 0) {
            return false;
        }
    }
    return true;
}

$unprime = array();
for ($s = 1; $s < 100; $s++) {
    if (!checkPrime($s)) {
        $array = array();
        for ($i = 1; $i <= $s; $i++) {
            if ($s % $i === 0) {
                $array[] = $i;
            }
        }
        $unprime[$s] = $array;
    }
}
print_r($unprime);
