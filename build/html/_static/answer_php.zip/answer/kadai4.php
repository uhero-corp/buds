<?php

/**
 * 
 * @param int $number
 * @return string
 */
function kanjiNumeral($number)
{
    $kanji = array('〇', '一', '二', '三', '四', '五', '六', '七', '八', '九');
    $new = '';
    foreach (str_split($number) as $value) {
        $new = $new . $kanji[$value];
    }
    return $new;
}

/**
 * 
 * @param int $number
 * @return boolean
 */
function checkPrime($number)
{
    if ($number < 2) {
        return false;
    } else if ($number === 2) {
        return true;
    }
    for ($i = 2; $i < $number; $i++) {
        if ($number % $i === 0) {
            return false;
        }
    }
    return true;
}

$unprime = array();
for ($s = 1; $s < 100; $s++) {
    if (!checkPrime($s)) {
        $array = array();
        for ($i = 1; $i <= $s; $i++) {
            if ($s % $i === 0) {
                $array[] = $i;
            }
        }
        $unprime[$s] = $array;
    }
}

$kanjiUnprime = array();
foreach ($unprime as $key => $value) {
    foreach ($value as $key2 => $value2) {
        $kanjiUnprime[$key][$key2] = kanjiNumeral($value2);
    }
}

print_r($kanjiUnprime);
